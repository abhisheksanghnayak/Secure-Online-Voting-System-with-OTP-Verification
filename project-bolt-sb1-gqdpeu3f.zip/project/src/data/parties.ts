import { Party } from '../types';

export const parties: Party[] = [
  {
    id: 'congress',
    name: 'Congress',
    logoUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/4/45/Hand_INC.svg/800px-Hand_INC.svg.png',
    slogan: 'United Progressive Alliance'
  },
  {
    id: 'bjp',
    name: 'BJP',
    logoUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/1/1e/Bharatiya_Janata_Party_logo.svg/800px-Bharatiya_Janata_Party_logo.svg.png',
    slogan: 'Nation First'
  },
  {
    id: 'bsp',
    name: 'BSP',
    logoUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/d/d2/Elephant_Bahujan_Samaj_Party.svg/800px-Elephant_Bahujan_Samaj_Party.svg.png',
    slogan: 'Social Justice For All'
  },
  {
    id: 'jds',
    name: 'JDS',
    logoUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/7/7f/Janata_Dal_%28Secular%29_Symbol.svg/800px-Janata_Dal_%28Secular%29_Symbol.svg.png',
    slogan: 'Voice of the People'
  },
  {
    id: 'aap',
    name: 'AAP',
    logoUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/7/76/Aam_Aadmi_Party_logo.svg/800px-Aam_Aadmi_Party_logo.svg.png',
    slogan: 'Common Man\'s Party'
  }
];