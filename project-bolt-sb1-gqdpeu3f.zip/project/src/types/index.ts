export interface Party {
  id: string;
  name: string;
  logoUrl: string;
  slogan: string;
}

export interface VoteRecord {
  [partyId: string]: number;
}