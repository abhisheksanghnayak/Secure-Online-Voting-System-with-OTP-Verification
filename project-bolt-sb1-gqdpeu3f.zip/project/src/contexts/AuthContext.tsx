import React, { createContext, useState, useContext, ReactNode } from 'react';

interface User {
  email: string;
  isVerified: boolean;
  hasVoted: boolean;
}

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  login: (email: string) => void;
  verifyOTP: (otp: string) => Promise<boolean>;
  logout: () => void;
  markAsVoted: () => void;
}

const AuthContext = createContext<AuthContextType>({
  user: null,
  isAuthenticated: false,
  login: () => {},
  verifyOTP: async () => false,
  logout: () => {},
  markAsVoted: () => {},
});

export const useAuth = () => useContext(AuthContext);

interface AuthProviderProps {
  children: ReactNode;
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);

  // In a real app, we would use localStorage or cookies to persist the user state
  const isAuthenticated = !!user && user.isVerified;

  const login = (email: string) => {
    // In a real implementation, we would make an API call to send OTP
    setUser({ email, isVerified: false, hasVoted: false });
    
    // Simulate sending OTP
    console.log(`OTP sent to ${email}`);
  };

  const verifyOTP = async (otp: string): Promise<boolean> => {
    // In a real implementation, we would verify the OTP with the backend
    // For demo purposes, any 6-digit OTP is accepted
    if (otp.length === 6 && /^\d+$/.test(otp)) {
      setUser(prevUser => prevUser ? { ...prevUser, isVerified: true } : null);
      return true;
    }
    return false;
  };

  const logout = () => {
    setUser(null);
  };

  const markAsVoted = () => {
    setUser(prevUser => prevUser ? { ...prevUser, hasVoted: true } : null);
  };

  return (
    <AuthContext.Provider value={{ 
      user, 
      isAuthenticated, 
      login, 
      verifyOTP, 
      logout,
      markAsVoted
    }}>
      {children}
    </AuthContext.Provider>
  );
};