import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { VoteRecord } from '../types';

interface VotesContextType {
  votes: VoteRecord;
  castVote: (partyId: string) => Promise<void>;
}

const VotesContext = createContext<VotesContextType>({
  votes: {},
  castVote: async () => {},
});

export const useVotes = () => useContext(VotesContext);

interface VotesProviderProps {
  children: ReactNode;
}

export const VotesProvider: React.FC<VotesProviderProps> = ({ children }) => {
  const [votes, setVotes] = useState<VoteRecord>(() => {
    // Initialize with sample votes for demo purposes
    return {
      congress: 42,
      bjp: 56,
      bsp: 18,
      jds: 15,
      aap: 33
    };
  });

  // In a real application, this would fetch votes from a backend API
  useEffect(() => {
    // Mock fetching votes from an API
    const fetchVotes = async () => {
      // In a real app, this would be an API call
      console.log('Fetching votes data...');
    };

    fetchVotes();
  }, []);

  const castVote = async (partyId: string): Promise<void> => {
    return new Promise((resolve) => {
      // Simulate network delay
      setTimeout(() => {
        setVotes(prevVotes => ({
          ...prevVotes,
          [partyId]: (prevVotes[partyId] || 0) + 1
        }));
        resolve();
      }, 1000);
    });
  };

  return (
    <VotesContext.Provider value={{ votes, castVote }}>
      {children}
    </VotesContext.Provider>
  );
};