import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import { AlertTriangle } from 'lucide-react';
import PartyCard from './PartyCard';
import { parties } from '../../data/parties';
import { useVotes } from '../../contexts/VotesContext';

const VotingPage: React.FC = () => {
  const [selectedParty, setSelectedParty] = useState<string | null>(null);
  const [confirmationOpen, setConfirmationOpen] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { markAsVoted } = useAuth();
  const { castVote } = useVotes();
  const navigate = useNavigate();

  const handleSelectParty = (partyId: string) => {
    setSelectedParty(partyId);
  };

  const handleConfirmVote = async () => {
    if (!selectedParty) return;
    
    setIsSubmitting(true);
    
    try {
      // In a real app, this would make an API call to the backend
      await castVote(selectedParty);
      markAsVoted();
      navigate('/results');
    } catch (error) {
      console.error('Error casting vote:', error);
    } finally {
      setIsSubmitting(false);
      setConfirmationOpen(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-12">
          <h1 className="text-3xl font-extrabold text-gray-900 sm:text-4xl">
            Cast Your Vote
          </h1>
          <p className="mt-3 text-xl text-gray-500 sm:mt-4">
            Select a party to cast your vote. You can only vote once.
          </p>
        </div>

        <div className="bg-white rounded-lg shadow-lg p-6 mb-8">
          <div className="flex items-center p-4 mb-6 text-sm text-blue-800 border-l-4 border-blue-500 bg-blue-50">
            <AlertTriangle className="h-5 w-5 mr-2 text-blue-500" />
            <div>
              Your vote is secret and secure. Make sure you verify your selection before confirming.
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {parties.map((party) => (
              <PartyCard
                key={party.id}
                party={party}
                selected={selectedParty === party.id}
                onSelect={handleSelectParty}
              />
            ))}
          </div>
        </div>

        <div className="flex justify-center">
          <button
            onClick={() => setConfirmationOpen(true)}
            disabled={!selectedParty}
            className={`px-6 py-3 border border-transparent text-base font-medium rounded-md shadow-sm text-white ${
              !selectedParty
                ? 'bg-gray-400 cursor-not-allowed'
                : 'bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500'
            }`}
          >
            Confirm Vote
          </button>
        </div>
      </div>

      {/* Confirmation Modal */}
      {confirmationOpen && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-75 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-md w-full mx-4">
            <h3 className="text-lg font-medium text-gray-900 mb-4">Confirm Your Vote</h3>
            
            <p className="text-sm text-gray-500 mb-4">
              You are about to vote for <strong>{parties.find(p => p.id === selectedParty)?.name}</strong>. 
              This action cannot be undone.
            </p>
            
            <div className="flex justify-end space-x-3">
              <button
                onClick={() => setConfirmationOpen(false)}
                className="px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmVote}
                disabled={isSubmitting}
                className={`px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white ${
                  isSubmitting
                    ? 'bg-indigo-400 cursor-not-allowed'
                    : 'bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500'
                }`}
              >
                {isSubmitting ? 'Submitting...' : 'Confirm Vote'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default VotingPage;