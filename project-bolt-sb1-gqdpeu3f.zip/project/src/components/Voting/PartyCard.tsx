import React from 'react';
import { Check } from 'lucide-react';
import { Party } from '../../types';

interface PartyCardProps {
  party: Party;
  selected: boolean;
  onSelect: (partyId: string) => void;
}

const PartyCard: React.FC<PartyCardProps> = ({ party, selected, onSelect }) => {
  return (
    <div
      className={`border rounded-lg overflow-hidden transition-all cursor-pointer ${
        selected
          ? 'border-indigo-500 ring-2 ring-indigo-500 ring-opacity-50 shadow-lg transform scale-105'
          : 'border-gray-200 hover:border-indigo-200 hover:shadow'
      }`}
      onClick={() => onSelect(party.id)}
    >
      <div 
        className="h-32 bg-cover bg-center" 
        style={{ backgroundImage: `url(${party.logoUrl})` }}
      />
      
      <div className={`p-4 ${selected ? 'bg-indigo-50' : 'bg-white'}`}>
        <div className="flex justify-between items-center">
          <h3 className="font-semibold text-lg">{party.name}</h3>
          
          {selected && (
            <div className="bg-indigo-500 text-white rounded-full p-1">
              <Check className="h-4 w-4" />
            </div>
          )}
        </div>
        
        <p className="text-sm text-gray-500 mt-2">{party.slogan}</p>
      </div>
    </div>
  );
};

export default PartyCard;