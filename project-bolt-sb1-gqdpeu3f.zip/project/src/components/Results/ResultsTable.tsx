import React from 'react';
import { parties } from '../../data/parties';
import { VoteRecord } from '../../types';

interface ResultsTableProps {
  votes: VoteRecord;
}

const ResultsTable: React.FC<ResultsTableProps> = ({ votes }) => {
  const totalVotes = Object.values(votes).reduce((sum, count) => sum + count, 0);
  
  // Sort parties by votes (descending)
  const sortedParties = [...parties].sort((a, b) => 
    (votes[b.id] || 0) - (votes[a.id] || 0)
  );

  return (
    <div className="overflow-x-auto">
      <table className="min-w-full divide-y divide-gray-200">
        <thead className="bg-gray-50">
          <tr>
            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Rank
            </th>
            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Party
            </th>
            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Votes
            </th>
            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Percentage
            </th>
          </tr>
        </thead>
        <tbody className="bg-white divide-y divide-gray-200">
          {sortedParties.map((party, index) => {
            const voteCount = votes[party.id] || 0;
            const percentage = totalVotes > 0 ? (voteCount / totalVotes) * 100 : 0;
            
            return (
              <tr key={party.id} className={index === 0 ? "bg-green-50" : ""}>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                  {index + 1}
                  {index === 0 && totalVotes > 0 && (
                    <span className="ml-2 text-green-600">•</span>
                  )}
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center">
                    <div className="flex-shrink-0 h-10 w-10">
                      <img 
                        className="h-10 w-10 rounded-full object-cover" 
                        src={party.logoUrl} 
                        alt={party.name} 
                      />
                    </div>
                    <div className="ml-4">
                      <div className="text-sm font-medium text-gray-900">{party.name}</div>
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {voteCount} {voteCount === 1 ? 'vote' : 'votes'}
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center">
                    <span className="text-sm text-gray-500 mr-2">
                      {percentage.toFixed(1)}%
                    </span>
                    <div className="w-24 bg-gray-200 rounded-full h-2.5">
                      <div 
                        className="bg-indigo-600 h-2.5 rounded-full" 
                        style={{ width: `${percentage}%` }}
                      />
                    </div>
                  </div>
                </td>
              </tr>
            );
          })}
          
          {totalVotes === 0 && (
            <tr>
              <td colSpan={4} className="px-6 py-4 text-center text-sm text-gray-500">
                No votes have been cast yet.
              </td>
            </tr>
          )}
        </tbody>
        <tfoot>
          <tr className="bg-gray-50">
            <td colSpan={2} className="px-6 py-3 text-left text-sm font-medium text-gray-900">
              Total
            </td>
            <td className="px-6 py-3 text-left text-sm font-medium text-gray-900">
              {totalVotes} {totalVotes === 1 ? 'vote' : 'votes'}
            </td>
            <td className="px-6 py-3 text-left text-sm font-medium text-gray-900">
              100%
            </td>
          </tr>
        </tfoot>
      </table>
    </div>
  );
};

export default ResultsTable;