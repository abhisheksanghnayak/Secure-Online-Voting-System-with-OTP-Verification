import React, { useEffect, useState } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { useVotes } from '../../contexts/VotesContext';
import { parties } from '../../data/parties';
import PieChart from './PieChart';
import BarChart from './BarChart';
import ResultsTable from './ResultsTable';
import { RefreshCw } from 'lucide-react';

const ResultsPage: React.FC = () => {
  const { user } = useAuth();
  const { votes } = useVotes();
  const [refreshing, setRefreshing] = useState(false);

  // Function to handle refresh of results
  const handleRefresh = () => {
    setRefreshing(true);
    // In a real app, this would fetch the latest results from the backend
    setTimeout(() => {
      setRefreshing(false);
    }, 1000);
  };

  // Auto-refresh results every 30 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      handleRefresh();
    }, 30000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="min-h-screen bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-12">
          <h1 className="text-3xl font-extrabold text-gray-900 sm:text-4xl">
            Election Results
          </h1>
          
          {user?.hasVoted && (
            <div className="mt-3 inline-flex items-center px-4 py-2 rounded-full text-sm font-medium bg-green-100 text-green-800">
              <span className="mr-1">●</span> Your vote has been recorded
            </div>
          )}
          
          <div className="mt-4 flex justify-center items-center">
            <button
              onClick={handleRefresh}
              disabled={refreshing}
              className="inline-flex items-center text-sm text-gray-500 hover:text-gray-700"
            >
              <RefreshCw className={`h-4 w-4 mr-1 ${refreshing ? 'animate-spin' : ''}`} />
              {refreshing ? 'Refreshing...' : 'Refresh Results'}
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-12">
          <div className="bg-white rounded-lg shadow-lg p-6">
            <h2 className="text-xl font-semibold mb-6 text-center">Vote Distribution</h2>
            <div className="h-80">
              <PieChart votes={votes} />
            </div>
          </div>
          
          <div className="bg-white rounded-lg shadow-lg p-6">
            <h2 className="text-xl font-semibold mb-6 text-center">Vote Comparison</h2>
            <div className="h-80">
              <BarChart votes={votes} />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-lg p-6">
          <h2 className="text-xl font-semibold mb-4">Detailed Results</h2>
          <ResultsTable votes={votes} />
        </div>
      </div>
    </div>
  );
};

export default ResultsPage;