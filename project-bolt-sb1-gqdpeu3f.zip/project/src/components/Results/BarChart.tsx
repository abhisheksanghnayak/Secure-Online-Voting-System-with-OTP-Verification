import React from 'react';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';
import { Bar } from 'react-chartjs-2';
import { parties } from '../../data/parties';
import { VoteRecord } from '../../types';

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
);

interface BarChartProps {
  votes: VoteRecord;
}

const BarChart: React.FC<BarChartProps> = ({ votes }) => {
  const partyColors = {
    congress: '#0077CC', // Blue
    bjp: '#FF9933',      // Orange
    bsp: '#8B4513',      // Brown
    jds: '#00FF00',      // Green
    aap: '#3498DB',      // Light Blue
  };

  const labels = parties.map(party => party.name);
  const data = parties.map(party => votes[party.id] || 0);
  const backgroundColor = parties.map(party => partyColors[party.id as keyof typeof partyColors]);
  
  const chartData = {
    labels,
    datasets: [
      {
        label: 'Votes',
        data,
        backgroundColor,
        borderColor: backgroundColor.map(color => color),
        borderWidth: 1,
        borderRadius: 4,
      },
    ],
  };

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: false,
      },
      tooltip: {
        callbacks: {
          label: function(context: any) {
            const label = context.dataset.label || '';
            const value = context.raw || 0;
            const total = data.reduce((a, b) => a + b, 0);
            const percentage = total ? Math.round((value / total) * 100) : 0;
            return `${label}: ${value} (${percentage}%)`;
          }
        }
      }
    },
    scales: {
      y: {
        beginAtZero: true,
        ticks: {
          precision: 0,
        },
      },
    },
  };

  return <Bar data={chartData} options={options} />;
};

export default BarChart;