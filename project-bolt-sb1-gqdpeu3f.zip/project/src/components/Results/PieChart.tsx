import React from 'react';
import { Chart as ChartJS, ArcElement, Tooltip, Legend } from 'chart.js';
import { Pie } from 'react-chartjs-2';
import { parties } from '../../data/parties';
import { VoteRecord } from '../../types';

ChartJS.register(ArcElement, Tooltip, Legend);

interface PieChartProps {
  votes: VoteRecord;
}

const PieChart: React.FC<PieChartProps> = ({ votes }) => {
  const partyColors = {
    congress: '#0077CC', // Blue
    bjp: '#FF9933',      // Orange
    bsp: '#8B4513',      // Brown
    jds: '#00FF00',      // Green
    aap: '#3498DB',      // Light Blue
  };

  const labels = parties.map(party => party.name);
  const data = parties.map(party => votes[party.id] || 0);
  const backgroundColor = parties.map(party => partyColors[party.id as keyof typeof partyColors]);
  
  const chartData = {
    labels,
    datasets: [
      {
        data,
        backgroundColor,
        borderColor: backgroundColor.map(() => '#FFFFFF'),
        borderWidth: 2,
      },
    ],
  };

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'bottom' as const,
        labels: {
          padding: 20,
          font: {
            size: 12,
          },
        },
      },
      tooltip: {
        callbacks: {
          label: function(context: any) {
            const label = context.label || '';
            const value = context.raw || 0;
            const total = data.reduce((a, b) => a + b, 0);
            const percentage = total ? Math.round((value / total) * 100) : 0;
            return `${label}: ${value} votes (${percentage}%)`;
          }
        }
      }
    },
  };

  return <Pie data={chartData} options={options} />;
};

export default PieChart;